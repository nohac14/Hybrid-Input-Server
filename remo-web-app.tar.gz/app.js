/**
 * Remo Web App - Main Application Logic
 * A mobile-optimized remote control for computers
 */

// ===================================
// STATE MANAGEMENT
// ===================================
const state = {
    networkManager: null,
    savedComputers: [],
    lastComputer: null,
    settings: {
        sensitivity: 1.5,
        isScrollInverted: false
    },
    trackpad: {
        lastTouchPos: null,
        accumulatedDelta: { x: 0, y: 0 },
        updateTimer: null,
        updateInterval: 100, // 10 updates per second
        touchCount: 0,
        tapTimeout: null
    },
    scroll: {
        lastTouchY: null,
        accumulatedScroll: 0,
        updateTimer: null,
        updateInterval: 100
    },
    keyboard: {
        currentLayout: 'lowercase', // 'lowercase', 'uppercase', 'symbols'
        layouts: {
            lowercase: [
                ['q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p'],
                ['a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l'],
                ['z', 'x', 'c', 'v', 'b', 'n', 'm']
            ],
            uppercase: [
                ['Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P'],
                ['A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L'],
                ['Z', 'X', 'C', 'V', 'B', 'N', 'M']
            ],
            symbols: [
                ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0'],
                ['-', '/', ':', ';', '(', ')', '$', '&', '@', '"'],
                ['.', ',', '?', '!', "'"]
            ]
        }
    }
};

// ===================================
// INITIALIZATION
// ===================================
document.addEventListener('DOMContentLoaded', () => {
    console.log('🚀 Remo Web App initializing...');

    // Initialize network manager
    state.networkManager = new NetworkManager();

    // Load saved data
    loadSettings();
    loadSavedComputers();

    // Setup UI event listeners
    setupConnectionView();
    setupControllerView();
    setupKeyboard();
    setupSettings();
    setupModals();

    // Setup network event listeners
    state.networkManager.on('stateChange', handleConnectionStateChange);
    state.networkManager.on('error', handleConnectionError);

    // Try auto-connect to last computer
    if (state.lastComputer) {
        console.log('Auto-connecting to:', state.lastComputer.name);
        connectToComputer(state.lastComputer);
    }

    // Render saved computers
    renderSavedComputers();

    console.log('✅ App ready');
});

// ===================================
// DATA PERSISTENCE
// ===================================
function loadSettings() {
    const sensitivity = localStorage.getItem('mouseSensitivity');
    const isScrollInverted = localStorage.getItem('isScrollInverted');

    if (sensitivity) state.settings.sensitivity = parseFloat(sensitivity);
    if (isScrollInverted) state.settings.isScrollInverted = isScrollInverted === 'true';

    // Update UI
    const sensitivitySlider = document.getElementById('sensitivity-slider');
    const sensitivityValue = document.getElementById('sensitivity-value');
    const inverseScrollToggle = document.getElementById('inverse-scroll-toggle');

    if (sensitivitySlider) sensitivitySlider.value = state.settings.sensitivity;
    if (sensitivityValue) sensitivityValue.textContent = `${state.settings.sensitivity.toFixed(1)}x`;
    if (inverseScrollToggle && state.settings.isScrollInverted) {
        inverseScrollToggle.classList.add('active');
    }
}

function saveSettings() {
    localStorage.setItem('mouseSensitivity', state.settings.sensitivity.toString());
    localStorage.setItem('isScrollInverted', state.settings.isScrollInverted.toString());
}

function loadSavedComputers() {
    const saved = localStorage.getItem('savedComputers');
    const last = localStorage.getItem('lastConnectedComputer');

    if (saved) {
        try {
            state.savedComputers = JSON.parse(saved);
        } catch (e) {
            console.error('Failed to parse saved computers:', e);
            state.savedComputers = [];
        }
    }

    if (last) {
        try {
            state.lastComputer = JSON.parse(last);
        } catch (e) {
            console.error('Failed to parse last computer:', e);
        }
    }
}

function saveSavedComputers() {
    localStorage.setItem('savedComputers', JSON.stringify(state.savedComputers));
}

function saveLastComputer(computer) {
    state.lastComputer = computer;
    localStorage.setItem('lastConnectedComputer', JSON.stringify(computer));
}

// ===================================
// CONNECTION VIEW
// ===================================
function setupConnectionView() {
    const addBtn = document.getElementById('add-computer-btn');
    addBtn.addEventListener('click', () => {
        showModal('add-computer-modal');
    });
}

function renderSavedComputers() {
    const list = document.getElementById('saved-computers-list');
    list.innerHTML = '';

    if (state.savedComputers.length === 0) {
        list.innerHTML = '<div class="empty-state">No saved computers. Add one to get started!</div>';
        return;
    }

    state.savedComputers.forEach((computer, index) => {
        const card = document.createElement('button');
        card.className = 'computer-card';
        card.innerHTML = `
      <div class="icon">💻</div>
      <div class="name">${computer.name}</div>
    `;
        card.addEventListener('click', () => connectToComputer(computer));
        list.appendChild(card);
    });
}

function connectToComputer(computer) {
    console.log('Connecting to:', computer);
    state.networkManager.connectedComputerName = computer.name;
    state.networkManager.connect(computer.address);
    saveLastComputer(computer);
}

// ===================================
// CONTROLLER VIEW
// ===================================
function setupControllerView() {
    // Disconnect button
    document.getElementById('disconnect-btn').addEventListener('click', () => {
        state.networkManager.disconnect();
    });

    // Keyboard button
    document.getElementById('keyboard-btn').addEventListener('click', () => {
        showOverlay('keyboard-overlay');
    });

    // Settings button
    document.getElementById('settings-btn').addEventListener('click', () => {
        showOverlay('settings-overlay');
    });

    // Setup trackpad
    setupTrackpad();

    // Setup scroll zone
    setupScrollZone();

    // Bottom buttons
    document.getElementById('left-click-btn').addEventListener('click', () => {
        vibrate(10);
        state.networkManager.sendCommand('mclick,left');
    });

    document.getElementById('right-click-btn').addEventListener('click', () => {
        vibrate(10);
        state.networkManager.sendCommand('mclick,right');
    });

    document.getElementById('mute-btn').addEventListener('click', () => {
        vibrate(10);
        state.networkManager.sendCommand('vol,mute');
    });
}

function setupTrackpad() {
    const trackpad = document.getElementById('trackpad');
    let touchStartTime = 0;
    let hasMoved = false;

    trackpad.addEventListener('touchstart', (e) => {
        e.preventDefault();
        const touches = e.touches;
        state.trackpad.touchCount = touches.length;
        touchStartTime = Date.now();
        hasMoved = false;

        if (touches.length === 1) {
            state.trackpad.lastTouchPos = {
                x: touches[0].clientX,
                y: touches[0].clientY
            };
        }

        trackpad.classList.add('touching');
    }, { passive: false });

    trackpad.addEventListener('touchmove', (e) => {
        e.preventDefault();
        const touches = e.touches;

        if (touches.length === 1 && state.trackpad.lastTouchPos) {
            hasMoved = true;
            const dx = touches[0].clientX - state.trackpad.lastTouchPos.x;
            const dy = touches[0].clientY - state.trackpad.lastTouchPos.y;

            state.trackpad.accumulatedDelta.x += dx;
            state.trackpad.accumulatedDelta.y += dy;

            state.trackpad.lastTouchPos = {
                x: touches[0].clientX,
                y: touches[0].clientY
            };

            // Start update timer if not already running
            if (!state.trackpad.updateTimer) {
                startTrackpadTimer();
            }
        }
    }, { passive: false });

    trackpad.addEventListener('touchend', (e) => {
        e.preventDefault();
        trackpad.classList.remove('touching');

        const touchDuration = Date.now() - touchStartTime;

        // Detect taps (quick touch without movement)
        if (!hasMoved && touchDuration < 200) {
            if (state.trackpad.touchCount === 1) {
                // Single tap = left click
                vibrate(10);
                state.networkManager.sendCommand('mclick,left');
            } else if (state.trackpad.touchCount === 2) {
                // Two-finger tap = right click
                vibrate(10);
                state.networkManager.sendCommand('mclick,right');
            }
        }

        // Cleanup
        stopTrackpadTimer();
        sendAccumulatedMovement();
        state.trackpad.lastTouchPos = null;
        state.trackpad.touchCount = 0;
    }, { passive: false });
}

function startTrackpadTimer() {
    state.trackpad.updateTimer = setInterval(() => {
        sendAccumulatedMovement();
    }, state.trackpad.updateInterval);
}

function stopTrackpadTimer() {
    if (state.trackpad.updateTimer) {
        clearInterval(state.trackpad.updateTimer);
        state.trackpad.updateTimer = null;
    }
}

function sendAccumulatedMovement() {
    const delta = state.trackpad.accumulatedDelta;
    if (delta.x === 0 && delta.y === 0) return;

    const dx = Math.round(delta.x * state.settings.sensitivity);
    const dy = Math.round(delta.y * state.settings.sensitivity);

    if (dx !== 0 || dy !== 0) {
        state.networkManager.sendCommand(`mmove,${dx},${dy}`);
    }

    state.trackpad.accumulatedDelta = { x: 0, y: 0 };
}

function setupScrollZone() {
    const scrollZone = document.getElementById('scroll-zone');

    scrollZone.addEventListener('touchstart', (e) => {
        e.preventDefault();
        if (e.touches.length === 1) {
            state.scroll.lastTouchY = e.touches[0].clientY;
        }
    }, { passive: false });

    scrollZone.addEventListener('touchmove', (e) => {
        e.preventDefault();

        if (e.touches.length === 1 && state.scroll.lastTouchY !== null) {
            const dy = e.touches[0].clientY - state.scroll.lastTouchY;
            state.scroll.accumulatedScroll += dy;
            state.scroll.lastTouchY = e.touches[0].clientY;

            if (!state.scroll.updateTimer) {
                startScrollTimer();
            }
        }
    }, { passive: false });

    scrollZone.addEventListener('touchend', (e) => {
        e.preventDefault();
        stopScrollTimer();
        sendAccumulatedScroll();
        state.scroll.lastTouchY = null;
    }, { passive: false });
}

function startScrollTimer() {
    state.scroll.updateTimer = setInterval(() => {
        sendAccumulatedScroll();
    }, state.scroll.updateInterval);
}

function stopScrollTimer() {
    if (state.scroll.updateTimer) {
        clearInterval(state.scroll.updateTimer);
        state.scroll.updateTimer = null;
    }
}

function sendAccumulatedScroll() {
    if (state.scroll.accumulatedScroll === 0) return;

    const direction = state.settings.isScrollInverted ? 1 : -1;
    const scrollAmount = Math.round((direction * state.scroll.accumulatedScroll) / 5);

    if (scrollAmount !== 0) {
        vibrate(5);
        state.networkManager.sendCommand(`scroll,${scrollAmount}`);
    }

    state.scroll.accumulatedScroll = 0;
}

// ===================================
// KEYBOARD
// ===================================
function setupKeyboard() {
    // Done button
    document.getElementById('keyboard-done-btn').addEventListener('click', () => {
        hideOverlay('keyboard-overlay');
    });

    // Shift button
    document.getElementById('shift-btn').addEventListener('click', () => {
        toggleKeyboardCase();
    });

    // Layout switch button (123 / ABC)
    document.getElementById('layout-switch-btn').addEventListener('click', () => {
        toggleKeyboardLayout();
    });

    // All key buttons
    document.querySelectorAll('.key-btn[data-key]').forEach(btn => {
        btn.addEventListener('click', () => {
            const key = btn.getAttribute('data-key');
            sendKey(key);
        });
    });
}

function sendKey(key) {
    vibrate(5);
    state.networkManager.sendCommand(`kpress,${key}`);

    // Auto-shift: return to lowercase after typing an uppercase letter
    if (state.keyboard.currentLayout === 'uppercase') {
        state.keyboard.currentLayout = 'lowercase';
        updateKeyboardLayout();
    }
}

function toggleKeyboardCase() {
    if (state.keyboard.currentLayout === 'lowercase') {
        state.keyboard.currentLayout = 'uppercase';
    } else if (state.keyboard.currentLayout === 'uppercase') {
        state.keyboard.currentLayout = 'lowercase';
    }
    updateKeyboardLayout();
}

function toggleKeyboardLayout() {
    const btn = document.getElementById('layout-switch-btn');

    if (state.keyboard.currentLayout === 'symbols') {
        state.keyboard.currentLayout = 'lowercase';
        btn.textContent = '123';
    } else {
        state.keyboard.currentLayout = 'symbols';
        btn.textContent = 'ABC';
    }

    updateKeyboardLayout();
}

function updateKeyboardLayout() {
    const layout = state.keyboard.layouts[state.keyboard.currentLayout];
    const shiftBtn = document.getElementById('shift-btn');

    // Update shift button appearance
    if (state.keyboard.currentLayout === 'uppercase') {
        shiftBtn.style.background = 'var(--color-accent-gradient)';
        shiftBtn.style.color = 'white';
    } else {
        shiftBtn.style.background = '';
        shiftBtn.style.color = '';
    }

    // Hide shift and delete for symbols layout
    const row3 = document.getElementById('keyboard-row-3');
    if (state.keyboard.currentLayout === 'symbols') {
        shiftBtn.style.display = 'none';
        row3.querySelector('[data-key="backspace"]').style.display = 'none';
    } else {
        shiftBtn.style.display = '';
        row3.querySelector('[data-key="backspace"]').style.display = '';
    }

    // Update key labels
    const rows = [
        document.getElementById('keyboard-row-1'),
        document.getElementById('keyboard-row-2'),
        document.getElementById('keyboard-row-3')
    ];

    layout.forEach((rowKeys, rowIndex) => {
        const row = rows[rowIndex];
        const keyButtons = row.querySelectorAll('.key-btn[data-key]');

        rowKeys.forEach((key, keyIndex) => {
            if (keyButtons[keyIndex]) {
                keyButtons[keyIndex].textContent = key;
                keyButtons[keyIndex].setAttribute('data-key', key);
            }
        });
    });
}

// ===================================
// SETTINGS
// ===================================
function setupSettings() {
    // Done button
    document.getElementById('settings-done-btn').addEventListener('click', () => {
        hideOverlay('settings-overlay');
    });

    // Sensitivity slider
    const slider = document.getElementById('sensitivity-slider');
    const valueDisplay = document.getElementById('sensitivity-value');

    slider.addEventListener('input', (e) => {
        const value = parseFloat(e.target.value);
        state.settings.sensitivity = value;
        valueDisplay.textContent = `${value.toFixed(1)}x`;
        saveSettings();
    });

    // Inverse scroll toggle
    const toggle = document.getElementById('inverse-scroll-toggle');
    toggle.addEventListener('click', () => {
        state.settings.isScrollInverted = !state.settings.isScrollInverted;
        toggle.classList.toggle('active');
        saveSettings();
    });
}

// ===================================
// MODALS
// ===================================
function setupModals() {
    // Add computer modal
    const cancelBtn = document.getElementById('cancel-add-btn');
    const saveBtn = document.getElementById('save-add-btn');
    const nameInput = document.getElementById('computer-name-input');
    const addressInput = document.getElementById('computer-address-input');

    cancelBtn.addEventListener('click', () => {
        hideModal('add-computer-modal');
        nameInput.value = '';
        addressInput.value = '';
    });

    saveBtn.addEventListener('click', () => {
        const name = nameInput.value.trim();
        const address = addressInput.value.trim();

        if (name && address) {
            const computer = { name, address };
            state.savedComputers.push(computer);
            saveSavedComputers();
            renderSavedComputers();
            hideModal('add-computer-modal');
            nameInput.value = '';
            addressInput.value = '';

            // Automatically connect to the new computer
            connectToComputer(computer);
        }
    });

    // Enable/disable save button based on input
    const updateSaveButton = () => {
        saveBtn.disabled = !nameInput.value.trim() || !addressInput.value.trim();
    };
    nameInput.addEventListener('input', updateSaveButton);
    addressInput.addEventListener('input', updateSaveButton);
}

function showModal(modalId) {
    document.getElementById(modalId).classList.remove('hidden');
}

function hideModal(modalId) {
    document.getElementById(modalId).classList.add('hidden');
}

function showOverlay(overlayId) {
    document.getElementById(overlayId).classList.remove('hidden');
}

function hideOverlay(overlayId) {
    document.getElementById(overlayId).classList.add('hidden');
}

// ===================================
// CONNECTION STATE HANDLING
// ===================================
function handleConnectionStateChange(data) {
    const connectionView = document.getElementById('connection-view');
    const controllerView = document.getElementById('controller-view');
    const computerNameEl = document.getElementById('computer-name');

    if (data.connected) {
        // Switch to controller view
        connectionView.classList.add('hidden');
        controllerView.classList.remove('hidden');
        computerNameEl.textContent = state.networkManager.connectedComputerName || 'Connected';
        console.log('✅ Connected to computer');
    } else {
        // Switch to connection view
        controllerView.classList.add('hidden');
        connectionView.classList.remove('hidden');
        console.log('Disconnected from computer');
    }
}

function handleConnectionError(data) {
    console.error('Connection error:', data.message);
    // Could show a toast notification here
    alert(`Connection Error: ${data.message}`);
}

// ===================================
// UTILITY FUNCTIONS
// ===================================
function vibrate(duration = 10) {
    if ('vibrate' in navigator) {
        navigator.vibrate(duration);
    }
}
