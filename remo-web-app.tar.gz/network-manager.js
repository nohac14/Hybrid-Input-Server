/**
 * NetworkManager - Handles WebSocket connections to the remote computer
 * 
 * Note: The iOS app uses raw TCP/UDP sockets, but browsers require WebSocket.
 * This assumes the server supports WebSocket connections.
 */
class NetworkManager {
  constructor() {
    this.ws = null;
    this.isConnected = false;
    this.connectedComputerName = null;
    this.connectedComputerAddress = null;
    this.listeners = {
      stateChange: [],
      error: []
    };
    this.reconnectAttempts = 0;
    this.maxReconnectAttempts = 3;
  }

  /**
   * Connect to a remote computer via WebSocket
   * @param {string} address - IP address or hostname
   * @param {number} port - WebSocket port (default: 65432)
   */
  connect(address, port = 65432) {
    try {
      // Close existing connection if any
      if (this.ws) {
        this.ws.close();
      }

      // Create WebSocket connection
      // Use ws:// for local network connections
      const wsUrl = `ws://${address}:${port}`;
      console.log('Connecting to:', wsUrl);
      
      this.ws = new WebSocket(wsUrl);
      this.connectedComputerAddress = address;

      this.ws.onopen = () => {
        console.log('✅ WebSocket connected');
        this.isConnected = true;
        this.reconnectAttempts = 0;
        this.emit('stateChange', { connected: true });
      };

      this.ws.onclose = (event) => {
        console.log('🔌 WebSocket closed', event.code, event.reason);
        const wasConnected = this.isConnected;
        this.isConnected = false;
        this.emit('stateChange', { connected: false });

        // Auto-reconnect if it was an unexpected disconnect
        if (wasConnected && this.reconnectAttempts < this.maxReconnectAttempts) {
          this.reconnectAttempts++;
          console.log(`Reconnecting... (attempt ${this.reconnectAttempts})`);
          setTimeout(() => this.connect(address, port), 2000);
        }
      };

      this.ws.onerror = (error) => {
        console.error('❌ WebSocket error:', error);
        this.emit('error', { message: 'Connection failed' });
      };

      this.ws.onmessage = (event) => {
        console.log('📨 Message from server:', event.data);
        // Handle any messages from server if needed
      };

    } catch (error) {
      console.error('Connection error:', error);
      this.emit('error', { message: error.message });
    }
  }

  /**
   * Disconnect from the remote computer
   */
  disconnect() {
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }
    this.isConnected = false;
    this.connectedComputerName = null;
    this.connectedComputerAddress = null;
    this.reconnectAttempts = this.maxReconnectAttempts; // Prevent auto-reconnect
    this.emit('stateChange', { connected: false });
  }

  /**
   * Send a command to the remote computer
   * @param {string} command - Command string (e.g., "mmove,10,20")
   */
  sendCommand(command) {
    if (!this.isConnected || !this.ws || this.ws.readyState !== WebSocket.OPEN) {
      console.warn('Cannot send command: not connected');
      return false;
    }

    try {
      // Commands are sent with a newline delimiter (like the iOS app)
      this.ws.send(command + '\n');
      return true;
    } catch (error) {
      console.error('Error sending command:', error);
      return false;
    }
  }

  /**
   * Register an event listener
   * @param {string} event - Event name ('stateChange' or 'error')
   * @param {function} callback - Callback function
   */
  on(event, callback) {
    if (this.listeners[event]) {
      this.listeners[event].push(callback);
    }
  }

  /**
   * Emit an event to all listeners
   * @param {string} event - Event name
   * @param {object} data - Event data
   */
  emit(event, data) {
    if (this.listeners[event]) {
      this.listeners[event].forEach(callback => callback(data));
    }
  }
}

// Export for use in app.js
window.NetworkManager = NetworkManager;
