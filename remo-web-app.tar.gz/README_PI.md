# Remo Web App - Raspberry Pi Setup

## Quick Start

### 1. Transfer to Raspberry Pi

Copy `remo-web-app.tar.gz` to your Raspberry Pi using one of these methods:

**Via SCP:**
```bash
scp remo-web-app.tar.gz pi@raspberrypi.local:~/
```

**Via USB drive:**
- Copy file to USB drive
- Plug into Pi
- Copy from `/media/pi/USB_NAME/` to home directory

### 2. Extract Files

```bash
cd ~
tar -xzf remo-web-app.tar.gz
cd remo-web-app
```

### 3. Make Script Executable

```bash
chmod +x start.sh
```

### 4. Run the Server

```bash
./start.sh
```

That's it! The script will show you the URL to access from your phone.

## Auto-Start on Boot (Optional)

To make the web app start automatically when the Pi boots:

```bash
# Create systemd service
sudo nano /etc/systemd/system/remo-web.service
```

Paste this content:
```ini
[Unit]
Description=Remo Web App Server
After=network.target

[Service]
Type=simple
User=pi
WorkingDirectory=/home/pi/remo-web-app
ExecStart=/usr/bin/python3 -m http.server 8000
Restart=always

[Install]
WantedBy=multi-user.target
```

Then enable and start:
```bash
sudo systemctl enable remo-web.service
sudo systemctl start remo-web.service
```

Check status:
```bash
sudo systemctl status remo-web.service
```

## Accessing the Web App

Once the server is running:
1. Find your Pi's IP address (shown when you run `./start.sh`)
2. On your phone, connect to same WiFi
3. Open browser to `http://PI_IP_ADDRESS:8000`
4. Add your computer and start controlling!

## Troubleshooting

**Q: Can't access from phone?**
- Make sure phone and Pi are on same WiFi network
- Check firewall settings on Pi
- Verify server is running: `ps aux | grep http.server`

**Q: Want to use a different port?**
- Edit `start.sh` and change `8000` to your preferred port
- Remember to use the new port in your browser

**Q: How to stop the server?**
- If running manually: Press `Ctrl+C`
- If running as service: `sudo systemctl stop remo-web.service`
