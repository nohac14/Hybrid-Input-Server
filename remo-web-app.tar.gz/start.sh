#!/bin/bash
# Remo Web App Startup Script
# Simple HTTP server for serving the web app

echo "🚀 Starting Remo Web App Server..."
echo ""

# Get local IP address
if command -v hostname &> /dev/null; then
    IP=$(hostname -I | awk '{print $1}')
else
    IP=$(ip addr show | grep "inet " | grep -v 127.0.0.1 | awk '{print $2}' | cut -d/ -f1 | head -n1)
fi

echo "========================================="
echo "  Remo Web App - Remote Control"
echo "========================================="
echo ""
echo "📡 Server running at:"
echo "   http://${IP}:8000"
echo ""
echo "📱 On your phone:"
echo "   1. Connect to the same WiFi network"
echo "   2. Open browser and go to:"
echo "      http://${IP}:8000"
echo ""
echo "🛑 Press Ctrl+C to stop the server"
echo "========================================="
echo ""

# Start Python HTTP server
python3 -m http.server 8000
